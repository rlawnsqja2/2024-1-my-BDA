import pandas as pd
import matplotlib.pyplot as plt

from ch05.example_02_common import get_covid_data as get_covid

korea_index_df = get_covid('South Korea')
print('=' * 50)
print(korea_index_df.head())

korea_total_cases = korea_index_df['total_cases']
usa_total_cases = korea_index_df['total_cases']
data_index = korea_index_df.index

df = pd.DataFrame(
    {
           'KOR': korea_total_cases,
           'USA': usa_total_cases
           },
    index=[1990, 1997, 2003, 2009, 2014])
df.plot.line()

plt.show()
print('=' * 50)
print(data_index)
