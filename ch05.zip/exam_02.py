import pandas as pd
def get_covid_data():

    file_path = '../ch04/data/owid-covid-data.csv'
    raw_df = pd.read_csv(file_path)

    selected_columns = ['iso_code', 'location', 'date', 'total_cases', 'population']

    selected_df = raw_df[selected_columns]

    # South Korea
    south_korea_df = selected_df[selected_df.location == 'South Korea']

    south_korea_index_df = south_korea_df.set_index('date')
    
    return south_korea_index_df

korea_index_df = get_covid_data('South Korea')
print('=' * 50)
print(korea_index_df.head())

usa_index_df = get_covid_data('United States')
print('=' * 50)
print(usa_index_df)

#end-def