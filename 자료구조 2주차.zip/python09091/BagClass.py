class BagClass:
    # 변수 - 데이터(속성)
    # 속성(arrtibute, property), 멤버 데이터
    # myBag = []
    
    # python의 객체 생성자
    def __init__(self, element):
        self.myBag = [ element ]
        #pass
        
    # 함수 - 데이터에 관련된 함수들만 모아놓자
    # 메서드(method), 멤버 함수
        
    def count(self):
        return len(self.myBag)
        
    def insert(self, element):
        self.myBag.append(element)
        
    def remove(self, element):
        self.myBag.remove(element)
        
    def list(self):
        return self.myBag
    
    def contains(self, element):
        return element in self.myBag
    
if __name__ == "__main__":
    bag = BagClass('손수건')  # 객체 생성
    
    # 객체 내부의 데이터 확인
    print( bag.myBag )     # print(bag.list())
    # 객체지향에서는 객체 내부 데이터를 직접 접근하지 않는다.
    # 캡슐화
    # 접근제한자 private, public
    
    bag.insert("지갑")
    print(bag.list())
    
    bag.insert("손수건")
    print(bag.list())
    
    print(bag.contains('빗'))
    
    bag.remove('손수건')
    print( bag.list() )