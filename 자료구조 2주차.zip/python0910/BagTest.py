mybag = []
mybag.append('손수건')
mybag.append('지갑')
mybag.append('손수건')
print(mybag)
mybag.remove('손수건')
print("remove 이후", mybag)
