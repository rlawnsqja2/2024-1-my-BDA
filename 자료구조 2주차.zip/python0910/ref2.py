def myfunc1(x, y):
    #pass
    x = 100
    y = 200 
    print( id(x) )
    print( id(y) )
    return x + y

def myfunc2():
    global a
    global b
    a = 100
    b = 200
    print('함수에서 a의 id는', id(a) )
    print('함수에서 b의 id는', id(b) )
    return a + b
    
    
a = 10
b = 20
print( a + b)
print('a의 id는', id(a) )
print('b의 id는', id(b) )

#print( myfunc1(a, b) )
#print(a + b)
print("myfunc2()호출 결과는", myfunc2() )
print("함수 호출한 뒤에...", a + b)