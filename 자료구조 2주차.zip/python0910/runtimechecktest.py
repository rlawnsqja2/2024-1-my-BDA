import time

start = time.time()
# 실행 시간을 측정하려는 코드 블록
sum = 0
for i in range(0, 10000000):
    #pass
    sum += i
print(f"0 ~ 9999까지의 합계는 {sum}")
end = time.time()
print(f"코드의 실행시간은 {end - start}")