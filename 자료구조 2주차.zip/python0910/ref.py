import sys
a = 10

print( id(a) ) # 변수의 고유번호
print( sys.getrefcount(a) )

b = []
print( id(b) )
print( sys.getrefcount(b) )
b.append(200)
del b
print( id(b) )

c = 1.54
print( id(c) )
print( sys.getrefcount(c) )