def contains(bag, e):
    return e in bag

def insert(bag, e) :
    bag.append(e)

def remove(bag, e) :
    bag.remove(e)

def count(bag):
    return len(bag)

# 코드 1.2: Bag을 활용한 테스트 프로그램
myBag = []
